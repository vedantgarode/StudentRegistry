Batch B4
Team Members :
	1)Mousam Singh SEB64
	2)Nishant Shinde SEB69
	3)Vedant Garode SEB66


Install OpenCV lib using CMD

1)Open CMD
2)Type " pip install opencv-python
3)run file